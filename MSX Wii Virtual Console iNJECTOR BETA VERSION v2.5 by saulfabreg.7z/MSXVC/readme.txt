MSX Wii Virtual Console (Wii VC) iNJECTOR ***BETA VERSION***

Made by saulfabreg (special thanks to icefire, BFGR and Superken7)
Email: saulfabregamboa@outlook.com
Website: http://saulfabreg-wiivc.blogspot.com

Welcome to the MSX1 / MSX2 Wii VC iNJECTOR!!!

This tool, made by me, using some utile tools fom other people,
allows you to inject your favorite MSX1 & MSX2 games in *.rom
format as Wii Virtual Console games.

You NEED the following files for inject your ROM as a Wii VC WAD:
- A MSX1 or MSX2 Wii Virtual Console original WAD (I recommend
  Road Fighter (J) (MSX1) and Metal Gear (J) (MSX2)
- A MSX1 / MSX2 ROM file in *.rom format

- u8it.exe tool (c) icefire
- gzinject.exe tool (c) krimtonz
- FreeTheWads.exe tool (c) Superken7
- everything else (c) saulfabreg
Made with love by saulfabreg (saulfabregamboa@outlook.com)
http://saulfabreg-wiivc.blogspot.com
---------------------------------------------------------------
CAUTION: This is a BETA test version. May have a lot of bugs.
---------------------------------------------------------------
